The following directory owned by Triangle Rental Brokers.

Libraries:
JQuery

Preprocessors:
SASS
note: since SASS cascades, scss view files must be imported after the included modules and partials.

Package Manager:
Bower

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

🔮 Browsersync command from terminal:
browser-sync start --server --files


🔮 Sass watch command from terminal:
sass --sourcemap=none --watch assets/css/index.scss:assets/css/index.css
